// Run with Node and sharp installed. Pass the sharp package path when not on NODE_PATH.
// Generates all delivery sizes from the reviewed vector master, never from a resized PNG.
import { createRequire } from 'node:module';
import { readFile, writeFile, mkdir } from 'node:fs/promises';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
const require = createRequire(import.meta.url);
const sharp = require(process.env.MEMOIRES_SHARP || 'sharp');
const here = dirname(fileURLToPath(import.meta.url));
const root = resolve(here, '../..');
const master = await readFile(resolve(here, 'mark.svg'), 'utf8');
const out = resolve(here, 'exports');
await mkdir(out, { recursive: true });
const themes = {
  light: { ink: '#171C20', paper: '#F6F4EF', amber: '#DBA439' },
  dark: { ink: '#F6F4EF', paper: '#11161B', amber: '#DBA439' },
  tinted: { ink: '#FFFFFF', paper: '#111111', amber: '#A8A8A8' },
};
function svg(theme, background = true) {
  const c = themes[theme];
  let source = master.replaceAll('#171C20', c.ink).replaceAll('#DBA439', c.amber);
  if (background) source = source.replace('<g ', `<rect x="128" y="104" width="512" height="512" fill="${c.paper}"/><g `);
  return source;
}
async function raster(source, size, path, opaque = false) {
  let image = sharp(Buffer.from(source), { density: 384 }).resize(size, size);
  if (opaque) image = image.removeAlpha();
  await image.toFile(path);
}
for (const theme of Object.keys(themes)) {
  const source = svg(theme);
  await writeFile(resolve(out, `appicon-${theme}.svg`), source);
  await raster(source, 1024, resolve(out, `appicon-${theme}.png`), true);
  if (theme !== 'tinted') {
    await writeFile(resolve(out, `mark-${theme}.svg`), svg(theme, false));
    await raster(svg(theme, false), 1024, resolve(out, `mark-${theme}.png`));
    await raster(source, 192, resolve(out, `appicon-${theme}-192.webp`), true);
  }
}
for (const size of [16, 32, 180]) {
  await raster(svg('light'), size, resolve(out, size === 180 ? 'apple-touch-icon.png' : `favicon-${size}x${size}.png`), true);
}
const adaptive = master.replace('<g ', '<style>g{fill:#171C20}.paper{fill:#F6F4EF}@media(prefers-color-scheme:dark){g{fill:#F6F4EF}.paper{fill:#11161B}}</style><rect class="paper" x="128" y="104" width="512" height="512"/><g ');
await writeFile(resolve(out, 'favicon.svg'), adaptive);
// Existing general-purpose asset paths remain valid for other consumers.
await raster(svg('light'), 1024, resolve(root, 'Assets/logo.png'), true);
await raster(svg('light', false), 1024, resolve(root, 'Assets/logo_nobg.png'));
const catalog = resolve(root, 'Memoires/Resources/Assets.xcassets');
for (const theme of Object.keys(themes)) {
  await raster(svg(theme), 1024, resolve(catalog, `AppIcon.appiconset/AppIcon${theme === 'light' ? '' : theme === 'dark' ? '-dark' : '-tinted'}.png`), true);
}
for (const theme of ['light', 'dark']) {
  await raster(svg(theme), 512, resolve(catalog, `AppLogo.imageset/AppLogo${theme === 'dark' ? '-dark' : ''}.png`), true);
}
console.log('Generated brand assets from Assets/Brand/mark.svg');

const wordmark = await readFile(resolve(here, 'wordmark.svg'), 'utf8');
const inner = source => source.slice(source.indexOf('>', source.indexOf('<svg')) + 1, source.lastIndexOf('</svg>'));
const variants = {
  light: ['#171C20', '#DBA439'], dark: ['#F6F4EF', '#DBA439'],
  black: ['#000000', '#000000'], white: ['#FFFFFF', '#FFFFFF'],
};
function symbol(color, accent) { return inner(master).replaceAll('#171C20', color).replaceAll('#DBA439', accent); }
function lettering(color) { return inner(wordmark).replaceAll('#171c20', color); }
function wrap(width, height, content) { return `<svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${height}" viewBox="0 0 ${width} ${height}">${content}</svg>`; }
function nested(x, y, w, h, viewBox, content) { return `<svg x="${x}" y="${y}" width="${w}" height="${h}" viewBox="${viewBox}">${content}</svg>`; }
async function deliver(name, source, width) {
  await writeFile(resolve(out, `${name}.svg`), source);
  await sharp(Buffer.from(source), { density: 192 }).resize({ width }).png().toFile(resolve(out, `${name}.png`));
}
for (const [variant, [color, accent]] of Object.entries(variants)) {
  await deliver(`symbol-${variant}`, wrap(512, 512, nested(0, 0, 512, 512, '128 104 512 512', symbol(color, accent))), 2048);
  await deliver(`wordmark-${variant}`, wrap(916, 232, nested(40, 40, 836, 151, '0 0 835.53906 150.87891', lettering(color))), 2400);
  await deliver(`logo-horizontal-${variant}`, wrap(1440, 360,
    nested(60, 46, 280, 268, '213 198 343 326', symbol(color, accent)) +
    nested(396, 95, 964, 174, '0 0 835.53906 150.87891', lettering(color))), 2880);
  await deliver(`logo-stacked-${variant}`, wrap(1024, 1100,
    nested(0, -24, 1024, 1024, '128 104 512 512', symbol(color, accent)) +
    nested(62, 850, 900, 163, '0 0 835.53906 150.87891', lettering(color))), 2048);
}
for (const theme of Object.keys(themes)) {
  const directory = resolve(out, 'icons', theme);
  await mkdir(directory, { recursive: true });
  for (const size of [20, 29, 40, 48, 58, 60, 64, 76, 80, 87, 120, 128, 152, 167, 180, 192, 256, 512, 1024]) {
    await raster(svg(theme), size, resolve(directory, `${size}.png`), true);
  }
}
const board = wrap(1600, 1200, ['light', 'dark'].map((theme, index) => {
  const c = themes[theme]; const x = index * 800;
  return `<rect x="${x}" width="800" height="1200" fill="${c.paper}"/>` +
    `<text x="${x + 64}" y="75" fill="${c.ink}" font-family="monospace" font-size="16" letter-spacing="4">${theme === 'light' ? 'CLARO' : 'OSCURO'}</text>` +
    nested(x + 40, 95, 720, 774, '0 0 1024 1100', inner(wrap(1024,1100,
      nested(0,-24,1024,1024,'128 104 512 512',symbol(c.ink,c.amber)) + nested(62,850,900,163,'0 0 835.53906 150.87891',lettering(c.ink))))) +
    nested(x + 64, 940, 144, 144, '128 104 512 512', inner(svg(theme))) +
    [64,32,16].map((size,i) => nested(x + 310 + i * 140, 1012 - size/2, size, size, '128 104 512 512', inner(svg(theme)))).join('');
}).join(''));
await writeFile(resolve(here, 'preview.svg'), board);
await sharp(Buffer.from(board)).png().toFile(resolve(here, 'preview.png'));
console.log('Generated complete logo set, icon sizes and preview');
